import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { projectsApi } from "../services/projectsApi";
import { datasetsApi } from "../services/datasetsApi";
import { modelsApi } from "../services/modelsApi";
import "../styles/data-upload.css";

const CONSTRAINT_TYPES = [
  "Minimum portfolio return",
  "Maximum portfolio return",
  "Maximum portfolio risk score",
  "Minimum portfolio risk score",
];

// Volatility is a percentage; Model Builder uses a 1-10 risk score.
// "score" = volatility / 3, kept between 0.5 and 10.
function toRisk(volatility, scale) {
  const v = Number(volatility);
  if (scale === "raw") return v;
  return Math.min(10, Math.max(0.5, Math.round((v / 3) * 10) / 10));
}

function averageRisk(assets) {
  return assets.reduce((s, a) => s + Number(a.riskScore), 0) / assets.length;
}

const REQUIRED_COLUMNS = ["ticker_or_asset", "historical_return", "volatility"];

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;

  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    const next = text[i + 1];

    if (char === '"') {
      if (quoted && next === '"') {
        cell += '"';
        i += 1;
      } else {
        quoted = !quoted;
      }
    } else if (char === "," && !quoted) {
      row.push(cell.trim());
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") i += 1;
      row.push(cell.trim());
      cell = "";
      if (row.some((value) => value !== "")) rows.push(row);
      row = [];
    } else {
      cell += char;
    }
  }

  if (cell !== "" || row.length) {
    row.push(cell.trim());
    if (row.some((value) => value !== "")) rows.push(row);
  }

  if (rows.length < 2) return [];
  const headers = rows[0].map((header) => header.trim().toLowerCase());
  return rows.slice(1).map((values) =>
    Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""]))
  );
}

function parseJson(text) {
  const value = JSON.parse(text);
  if (!Array.isArray(value)) {
    throw new Error("JSON data must contain an array of asset records.");
  }
  return value;
}

function validateRows(rows) {
  const warnings = [];
  if (!rows.length) return ["The file does not contain any data rows."];

  const first = rows[0];
  const missing = REQUIRED_COLUMNS.filter((column) => !(column in first));
  if (missing.length) {
    warnings.push(`Missing required columns: ${missing.join(", ")}.`);
    return warnings;
  }

  rows.forEach((row, index) => {
    const rowNumber = index + 2;
    if (!String(row.ticker_or_asset || "").trim()) {
      warnings.push(`Row ${rowNumber}: asset name is missing.`);
    }
    if (row.historical_return === "" || Number.isNaN(Number(row.historical_return))) {
      warnings.push(`Row ${rowNumber}: historical_return must be numeric.`);
    }
    if (row.volatility === "" || Number.isNaN(Number(row.volatility))) {
      warnings.push(`Row ${rowNumber}: volatility must be numeric.`);
    }
  });

  return warnings;
}

export default function DataUpload() {
  const [projects, setProjects] = useState([]);
  const [projectId, setProjectId] = useState("");
  const [file, setFile] = useState(null);
  const [rows, setRows] = useState([]);
  const [warnings, setWarnings] = useState([]);
  const [datasets, setDatasets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [parsing, setParsing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const fileInputRef = useRef(null);

  // "Create a model from this dataset" panel
  const [maker, setMaker] = useState(null); // the dataset a model is built from
  const [makerForm, setMakerForm] = useState({ name: "", objective: "Maximize Return", budget: "100000" });
  const [makerAssets, setMakerAssets] = useState([]);
  const [makerCons, setMakerCons] = useState([]);
  const [bulk, setBulk] = useState({ min: "0", max: "40" });
  const [scale, setScale] = useState("score"); // "score" = 1-10, "raw" = volatility %
  const [making, setMaking] = useState(false);

  useEffect(() => {
    projectsApi.list()
      .then((data) => setProjects(data.projects || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!projectId) return;
    datasetsApi.list(projectId)
      .then((data) => setDatasets(data.datasets || []))
      .catch((err) => setError(err.message));
  }, [projectId]);

  const selectedProject = useMemo(
    () => projects.find((project) => String(project.project_id) === String(projectId)),
    [projects, projectId]
  );

  // Loads the dataset rows and opens the panel with editable limits and constraints
  async function openMaker(dataset) {
    setError("");
    setMessage("");
    try {
      const data = await datasetsApi.rows(projectId, dataset.dataset_id);
      const list = data.rows || [];
      if (!list.length) return setError("This dataset has no rows.");

      const cap = Math.max(40, Math.ceil(100 / list.length));
      const assets = list.map((r) => ({
        assetName: r.ticker_or_asset,
        expectedReturn: r.historical_return,
        volatility: r.volatility,
        riskScore: toRisk(r.volatility, "score"),
        minAllocation: "0",
        maxAllocation: String(cap),
      }));

      setMaker(dataset);
      setScale("score");
      setMakerForm({
        name: `${dataset.file_name.replace(/\.(csv|json)$/i, "")} model`,
        objective: "Maximize Return",
        budget: "100000",
      });
      setBulk({ min: "0", max: String(cap) });
      setMakerAssets(assets);
      setMakerCons([
        {
          constraintType: "Maximum portfolio risk score",
          operator: "<=",
          targetValue: String(Math.ceil(averageRisk(assets) * 100) / 100),
        },
      ]);
    } catch (err) {
      setError(err.message || "Unable to load the dataset rows.");
    }
  }

  function updateMakerAsset(index, field, value) {
    setMakerAssets(makerAssets.map((a, i) => (i === index ? { ...a, [field]: value } : a)));
  }

  // Switch between the 1-10 score and the raw volatility %, and refresh the suggested risk limit
  function changeScale(mode) {
    const oldDefault = String(Math.ceil(averageRisk(makerAssets) * 100) / 100);
    const next = makerAssets.map((a) => ({ ...a, riskScore: toRisk(a.volatility, mode) }));
    const newDefault = String(Math.ceil(averageRisk(next) * 100) / 100);

    setScale(mode);
    setMakerAssets(next);
    setMakerCons(
      makerCons.map((c) =>
        c.constraintType === "Maximum portfolio risk score" && c.targetValue === oldDefault
          ? { ...c, targetValue: newDefault }
          : c
      )
    );
  }

  function applyBulk() {
    setMakerAssets(makerAssets.map((a) => ({ ...a, minAllocation: bulk.min, maxAllocation: bulk.max })));
  }

  function addMakerCon() {
    setMakerCons([...makerCons, { constraintType: CONSTRAINT_TYPES[0], operator: ">=", targetValue: "" }]);
  }

  function updateMakerCon(index, field, value) {
    setMakerCons(makerCons.map((c, i) => (i === index ? { ...c, [field]: value } : c)));
  }

  function removeMakerCon(index) {
    setMakerCons(makerCons.filter((_, i) => i !== index));
  }

  const sumMin = makerAssets.reduce((s, a) => s + (Number(a.minAllocation) || 0), 0);
  const sumMax = makerAssets.reduce((s, a) => s + (Number(a.maxAllocation) || 0), 0);

  async function createModel(event) {
    event.preventDefault();
    setError("");
    setMessage("");

    if (!makerForm.name.trim()) return setError("Please enter a model name.");
    if (!makerForm.budget || Number(makerForm.budget) <= 0) return setError("Please enter a valid total budget.");

    for (const a of makerAssets) {
      const min = Number(a.minAllocation);
      const max = Number(a.maxAllocation);
      if (Number.isNaN(min) || Number.isNaN(max) || min < 0 || max > 100 || min < 0 || max < 0) {
        return setError(`Allocations for ${a.assetName} must be numbers between 0 and 100.`);
      }
      if (min > max) return setError(`Minimum cannot exceed maximum for ${a.assetName}.`);
    }
    if (sumMin > 100) return setError(`The minimums add up to ${sumMin}%, which is more than 100%.`);
    if (sumMax < 100) return setError(`The maximums add up to ${sumMax}%, which is less than 100%. Raise some maximums.`);

    for (const c of makerCons) {
      if (c.targetValue === "" || Number.isNaN(Number(c.targetValue))) {
        return setError("Every constraint needs a numeric target.");
      }
    }

    try {
      setMaking(true);
      await modelsApi.save(projectId, {
        modelName: makerForm.name.trim(),
        objectiveType: makerForm.objective,
        totalBudget: Number(makerForm.budget),
        assets: makerAssets.map((a) => ({
          assetName: a.assetName,
          expectedReturn: Number(a.expectedReturn),
          riskScore: Number(a.riskScore),
          minAllocation: Number(a.minAllocation),
          maxAllocation: Number(a.maxAllocation),
        })),
        // The solver works in percentages, so targets are saved as value x 100
        constraints: makerCons.map((c) => ({
          constraintType: c.constraintType,
          operator: c.operator,
          targetValue: Number((Number(c.targetValue) * 100).toFixed(2)),
        })),
      });
      setMessage(`Model "${makerForm.name.trim()}" created from ${maker.file_name}. Open it in Model Builder or run it in Run Optimization.`);
      setMaker(null);
    } catch (err) {
      setError(err.message || "Unable to create the model.");
    } finally {
      setMaking(false);
    }
  }

  function handleProjectChange(event) {
    setMaker(null);
    setProjectId(event.target.value);
    setDatasets([]);
    setFile(null);
    setRows([]);
    setWarnings([]);
    setError("");
    setMessage("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  async function handleFile(event) {
    const selected = event.target.files?.[0];
    if (!selected) return;

    setFile(selected);
    setRows([]);
    setWarnings([]);
    setError("");
    setMessage("");
    setParsing(true);

    try {
      const extension = selected.name.split(".").pop()?.toLowerCase();
      if (!["csv", "json"].includes(extension)) {
        throw new Error("Please upload a CSV or JSON file.");
      }

      const text = await selected.text();
      const parsed = extension === "csv" ? parseCsv(text) : parseJson(text);
      const normalized = parsed.map((row) => ({
        ticker_or_asset: row.ticker_or_asset ?? row.ticker ?? row.asset_name ?? row.asset ?? "",
        historical_return: row.historical_return ?? row.expected_return ?? row.return ?? "",
        volatility: row.volatility ?? row.risk_score ?? row.risk ?? "",
      }));

      setRows(normalized);
      setWarnings(validateRows(normalized));
    } catch (err) {
      setError(err.message || "Unable to read this file.");
    } finally {
      setParsing(false);
    }
  }

  async function confirmUpload() {
    setError("");
    setMessage("");
    if (!projectId) return setError("Please select a project.");
    if (!file || !rows.length) return setError("Choose a valid CSV or JSON file first.");
    if (warnings.length) return setError("Fix the validation warnings before confirming the dataset.");

    try {
      setSaving(true);
      const uploadedName = file.name;
      const result = await datasetsApi.create(projectId, {
        fileName: uploadedName,
        rows,
      });
      setMessage(result.message || "Data confirmed attached to project.");
      setFile(null);
      setRows([]);
      setWarnings([]);
      if (fileInputRef.current) fileInputRef.current.value = "";
      const data = await datasetsApi.list(projectId);
      setDatasets(data.datasets || []);
      // Offer to turn the new dataset into a model right away
      openMaker({ dataset_id: result.datasetId, file_name: uploadedName });
    } catch (err) {
      setError(err.message || "Unable to save the dataset.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="data-upload">
      <header className="data-upload__header">
        <div>
        
          <h1>Upload Portfolio Data</h1>
          <p>Upload a CSV or JSON asset dataset, preview the rows, and attach the confirmed data to a project.</p>
        </div>
        <Link className="btn btn--ghost" to="/dashboard/model-builder">Open Model Builder</Link>
      </header>

      {message && <div className="alert alert--success" role="status">{message}</div>}
      {error && <div className="alert alert--error" role="alert">{error}</div>}

      <section className="data-upload__section">
        <div className="data-upload__section-head">
          <div>
            <h2>1. Select Project</h2>
            <p>Choose the project that should own this dataset.</p>
          </div>
        </div>
        <select value={projectId} onChange={handleProjectChange} disabled={loading}>
          <option value="">{loading ? "Loading projects..." : "Select a project"}</option>
          {projects.map((project) => (
            <option key={project.project_id} value={project.project_id}>{project.project_name}</option>
          ))}
        </select>
        {selectedProject && <p className="data-upload__hint">Dataset destination: <strong>{selectedProject.project_name}</strong></p>}
      </section>

      <section className="data-upload__section">
        <div className="data-upload__section-head">
          <div>
            <h2>2. Upload Dataset</h2>
            <p>Supported formats: CSV and JSON. Required fields are asset, historical return, and volatility.</p>
          </div>
        </div>
        <div className="data-upload__dropzone">
          <input ref={fileInputRef} id="portfolio-file" type="file" accept=".csv,.json,application/json,text/csv" onChange={handleFile} />
          <label htmlFor="portfolio-file" className="btn btn--primary">Choose CSV / JSON</label>
          {file && <span>{file.name}</span>}
        </div>
        {parsing && <p className="data-upload__status">Reading and validating file…</p>}
      </section>

      {rows.length > 0 && (
        <section className="data-upload__section">
          <div className="data-upload__section-head">
            <div>
              <h2>3. Preview</h2>
              <p>{rows.length} data row{rows.length === 1 ? "" : "s"} detected.</p>
            </div>
            <button className="btn btn--primary" type="button" onClick={confirmUpload} disabled={saving || warnings.length > 0}>
              {saving ? "Saving…" : "Confirm & Attach"}
            </button>
          </div>

          {warnings.length > 0 && (
            <div className="data-upload__warnings" role="alert">
              <strong>Validation warnings</strong>
              <ul>{warnings.slice(0, 10).map((warning) => <li key={warning}>{warning}</li>)}</ul>
              {warnings.length > 10 && <p>Only the first 10 warnings are shown.</p>}
            </div>
          )}

          <div className="data-upload__table-wrap">
            <table className="data-upload__table">
              <thead><tr><th>Asset</th><th>Historical Return</th><th>Volatility</th></tr></thead>
              <tbody>
                {rows.slice(0, 25).map((row, index) => (
                  <tr key={`${row.ticker_or_asset}-${index}`}>
                    <td>{row.ticker_or_asset}</td>
                    <td>{row.historical_return}</td>
                    <td>{row.volatility}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {rows.length > 25 && <p className="data-upload__hint">Showing the first 25 rows in the preview.</p>}
        </section>
      )}

      {maker && (
        <section className="data-upload__section maker">
          <div className="data-upload__section-head">
            <div>
              <h2>Create a model from {maker.file_name}</h2>
              <p>Return and volatility come from your file (volatility is turned into a 1–10 risk score; you can edit it). Set the allocation limits (0–100%) and the constraints below.</p>
            </div>
          </div>

          <form onSubmit={createModel} noValidate>
            <div className="grid">
              <label>
                Model name
                <input type="text" value={makerForm.name} onChange={(e) => setMakerForm({ ...makerForm, name: e.target.value })} />
              </label>
              <label>
                Objective
                <select value={makerForm.objective} onChange={(e) => setMakerForm({ ...makerForm, objective: e.target.value })}>
                  <option value="Maximize Return">Maximize Return</option>
                  <option value="Minimize Risk">Minimize Risk</option>
                </select>
              </label>
              <label>
                Total budget
                <input type="number" min="0" step="0.01" value={makerForm.budget} onChange={(e) => setMakerForm({ ...makerForm, budget: e.target.value })} />
              </label>
            </div>

            <h3>Assets</h3>
            <div className="bulk">
              <label className="wide">
                Risk score scale
                <select value={scale} onChange={(e) => changeScale(e.target.value)}>
                  <option value="score">1–10 score (volatility ÷ 3)</option>
                  <option value="raw">Volatility % from the file</option>
                </select>
              </label>
              <span>Set all assets:</span>
              <label>
                Min %
                <input type="number" min="0" max="100" value={bulk.min} onChange={(e) => setBulk({ ...bulk, min: e.target.value })} />
              </label>
              <label>
                Max %
                <input type="number" min="0" max="100" value={bulk.max} onChange={(e) => setBulk({ ...bulk, max: e.target.value })} />
              </label>
              <button type="button" className="make" onClick={applyBulk}>Apply to all</button>
            </div>

            <div className="data-upload__table-wrap">
              <table className="data-upload__table">
                <thead>
                  <tr>
                    <th>Asset</th>
                    <th>Expected return (%)</th>
                    <th>Risk score</th>
                    <th>Min allocation (%)</th>
                    <th>Max allocation (%)</th>
                  </tr>
                </thead>
                <tbody>
                  {makerAssets.map((a, index) => (
                    <tr key={`${a.assetName}-${index}`}>
                      <td>{a.assetName}</td>
                      <td>{a.expectedReturn}</td>
                      <td>
                        <input type="number" min="0" step="0.1" value={a.riskScore} onChange={(e) => updateMakerAsset(index, "riskScore", e.target.value)} />
                      </td>
                      <td>
                        <input type="number" min="0" max="100" step="0.01" value={a.minAllocation} onChange={(e) => updateMakerAsset(index, "minAllocation", e.target.value)} />
                      </td>
                      <td>
                        <input type="number" min="0" max="100" step="0.01" value={a.maxAllocation} onChange={(e) => updateMakerAsset(index, "maxAllocation", e.target.value)} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className={sumMin > 100 || sumMax < 100 ? "sum bad" : "sum"}>
              Minimums total {sumMin}% · maximums total {sumMax}% (minimums must be 100 or less, maximums 100 or more)
            </p>

            <h3>Constraints</h3>
            {makerCons.length === 0 && <p className="data-upload__hint">No constraints. The result will usually put everything in one asset.</p>}
            {makerCons.map((c, index) => (
              <div className="con" key={index}>
                <select value={c.constraintType} onChange={(e) => updateMakerCon(index, "constraintType", e.target.value)}>
                  {CONSTRAINT_TYPES.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
                <select value={c.operator} onChange={(e) => updateMakerCon(index, "operator", e.target.value)}>
                  <option value="<=">&lt;=</option>
                  <option value=">=">&gt;=</option>
                  <option value="=">=</option>
                </select>
                <input type="number" step="0.01" placeholder="Target" value={c.targetValue} onChange={(e) => updateMakerCon(index, "targetValue", e.target.value)} />
                <button type="button" className="make" onClick={() => removeMakerCon(index)}>Remove</button>
              </div>
            ))}
            <button type="button" className="make" onClick={addMakerCon}>+ Add constraint</button>
            <p className="data-upload__hint">
              Enter real values: 5 means 5% return, 4.5 means risk score 4.5. They are saved ×100 for the solver
              (so Model Builder will show 500 and 450).
            </p>

            <div className="buttons">
              <button type="submit" className="btn btn--primary" disabled={making}>
                {making ? "Creating…" : "Create model"}
              </button>
              <button type="button" className="btn btn--ghost btn--dark" onClick={() => setMaker(null)}>
                Not now
              </button>
            </div>
          </form>
        </section>
      )}

      {projectId && (
        <section className="data-upload__section">
          <div className="data-upload__section-head">
            <div><h2>Attached Datasets</h2><p>Previously confirmed datasets for this project.</p></div>
          </div>
          {datasets.length === 0 ? <p className="data-upload__empty">No datasets uploaded yet.</p> : (
            <ul className="data-upload__dataset-list">
              {datasets.map((dataset) => (
                <li key={dataset.dataset_id}>
                  <div><strong>{dataset.file_name}</strong><span>{dataset.row_count} rows</span></div>
                  <time>{new Date(dataset.uploaded_at).toLocaleString()}</time>
                  <button type="button" className="make" onClick={() => openMaker(dataset)}>Create model</button>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}
    </main>
  );
}
