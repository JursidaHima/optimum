
import { useEffect, useState } from "react";
import FormField from "../../components/FormField.jsx";
import { adminApi } from "../../services/adminApi";
import { formatDateTime } from "../../utils/format";

/* Sample configuration */

const SAMPLE_CONFIG = JSON.stringify(
  {
    modelName: "Maximum Expected Return",
    objectiveType: "Maximize Return",
    totalBudget: 10000,
    assets: [
      {
        assetName: "US Equity Fund",
        expectedReturn: 8,
        riskScore: 7,
        minAllocation: 0,
        maxAllocation: 5000
      },
      {
        assetName: "International Equity Fund",
        expectedReturn: 7,
        riskScore: 6,
        minAllocation: 0,
        maxAllocation: 5000
      },
      {
        assetName: "Bond Fund",
        expectedReturn: 4,
        riskScore: 2,
        minAllocation: 0,
        maxAllocation: 5000
      }
    ],
    constraints: []
  },
  null,
  2
);

/* Empty form */

const EMPTY = {
  templateName: "",
  description: "",
  defaultConfigJson: SAMPLE_CONFIG
};

/* Format configuration */

function formatConfig(value) {
  if (value === null || value === undefined) {
    return "";
  }

  try {
    const parsed =
      typeof value === "string"
        ? JSON.parse(value)
        : value;

    return JSON.stringify(parsed, null, 2);
  } catch {
    return String(value);
  }
}

/* Validate configuration */

function validateConfig(form) {
  if (!form.templateName.trim()) {
    return "Template name is required.";
  }

  if (!form.description.trim()) {
    return "Description is required.";
  }

  let config;

  try {
    config = JSON.parse(form.defaultConfigJson);
  } catch {
    return "Default configuration must contain valid JSON.";
  }

  if (
    !config ||
    typeof config !== "object" ||
    Array.isArray(config)
  ) {
    return "Configuration must be a JSON object.";
  }

  if (
    typeof config.modelName !== "string" ||
    !config.modelName.trim()
  ) {
    return "Model name is required.";
  }

  if (config.objectiveType !== "Maximize Return") {
    return "Objective type must be Maximize Return.";
  }

  if (
    !Number.isFinite(config.totalBudget) ||
    config.totalBudget <= 0
  ) {
    return "Total budget must be greater than zero.";
  }

  if (
    !Array.isArray(config.assets) ||
    config.assets.length === 0
  ) {
    return "Add at least one asset.";
  }

  let totalMinimum = 0;

  for (let i = 0; i < config.assets.length; i++) {
    const asset = config.assets[i];

    if (
      !asset ||
      typeof asset !== "object" ||
      Array.isArray(asset)
    ) {
      return `Asset ${i + 1} must be a valid object.`;
    }

    if (
      typeof asset.assetName !== "string" ||
      !asset.assetName.trim()
    ) {
      return `Asset ${i + 1} must have a name.`;
    }

    if (!Number.isFinite(asset.expectedReturn)) {
      return `Asset ${i + 1} must have a numeric expected return.`;
    }

    if (
      !Number.isInteger(asset.riskScore) ||
      asset.riskScore < 1 ||
      asset.riskScore > 10
    ) {
      return `Asset ${i + 1} risk score must be an integer from 1 to 10.`;
    }

    if (
      !Number.isFinite(asset.minAllocation) ||
      !Number.isFinite(asset.maxAllocation)
    ) {
      return `Asset ${i + 1} must have numeric allocation limits.`;
    }

    if (
      asset.minAllocation < 0 ||
      asset.maxAllocation < asset.minAllocation
    ) {
      return `Asset ${i + 1} has invalid allocation limits.`;
    }

    if (asset.maxAllocation > config.totalBudget) {
      return `Asset ${i + 1} maximum allocation cannot exceed the budget.`;
    }

    totalMinimum += asset.minAllocation;
  }

  if (totalMinimum > config.totalBudget) {
    return "Total minimum allocations exceed the investment budget.";
  }

  if (
    config.constraints !== undefined &&
    !Array.isArray(config.constraints)
  ) {
    return "Constraints must be an array.";
  }

  for (let i = 0; i < (config.constraints || []).length; i++) {
    const constraint = config.constraints[i];

    if (
      !constraint ||
      typeof constraint.constraintType !== "string" ||
      !constraint.constraintType.trim()
    ) {
      return `Constraint ${i + 1} must have a type.`;
    }

    if (!["<=", ">=", "="].includes(constraint.operator)) {
      return `Constraint ${i + 1} has an invalid operator.`;
    }

    if (!Number.isFinite(constraint.targetValue)) {
      return `Constraint ${i + 1} must have a numeric target value.`;
    }
  }

  return "";
}

/* Admin templates */

export default function AdminTemplates() {
  const [templates, setTemplates] = useState(null);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ ...EMPTY });

  const [formError, setFormError] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  /* Load templates */

  async function load() {
    try {
      setError("");

      const data = await adminApi.listTemplates();

      setTemplates(data.templates || []);
    } catch (err) {
      setError(err.message);
      setTemplates([]);
    }
  }

  useEffect(() => {
    load();
  }, []);

  /* New template */

  function openNew() {
    setEditing("new");
    setForm({ ...EMPTY });
    setFormError("");
    setNotice("");
  }

  /* Edit template */

  function openEdit(template) {
    setEditing(template);

    setForm({
      templateName: template.template_name || "",
      description: template.description || "",
      defaultConfigJson: formatConfig(
        template.default_config_json
      )
    });

    setFormError("");
    setNotice("");
  }

  /* Update field */

  function updateField(field, value) {
    setForm((previous) => ({
      ...previous,
      [field]: value
    }));
  }

  /* Format JSON */

  function onFormatJson() {
    try {
      const config = JSON.parse(form.defaultConfigJson);

      updateField(
        "defaultConfigJson",
        JSON.stringify(config, null, 2)
      );

      setFormError("");
    } catch {
      setFormError("Cannot format invalid JSON.");
    }
  }

  /* Save template */

  async function onSubmit(event) {
    event.preventDefault();

    setFormError("");
    setNotice("");

    const validationError = validateConfig(form);

    if (validationError) {
      setFormError(validationError);
      return;
    }

    setBusy(true);

    try {
      const config = JSON.parse(form.defaultConfigJson);

      const payload = {
        templateName: form.templateName.trim(),
        description: form.description.trim(),
        defaultConfigJson: JSON.stringify(config)
      };

      const response =
        editing === "new"
          ? await adminApi.createTemplate(payload)
          : await adminApi.updateTemplate(
              editing.template_id,
              payload
            );

      setNotice(
        response.message || "Template saved successfully."
      );

      setEditing(null);
      setForm({ ...EMPTY });

      await load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setBusy(false);
    }
  }

  /* Delete template */

  async function onDelete(template) {
    const confirmed = window.confirm(
      `Delete template "${template.template_name}"?`
    );

    if (!confirmed) {
      return;
    }

    setError("");
    setNotice("");
    setBusy(true);

    try {
      const response = await adminApi.deleteTemplate(
        template.template_id
      );

      setNotice(
        response.message || "Template deleted successfully."
      );

      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  /* Cancel editing */

  function onCancel() {
    setEditing(null);
    setForm({ ...EMPTY });
    setFormError("");
  }

  return (
    <section className="admin">

      {/* Header */}

      <header className="admin__header admin__header--row">
        <div>
          <h1>Templates</h1>

          <p>
            Starter finance models that administrators
            maintain for the platform.
          </p>
        </div>

        <button
          type="button"
          className="btn btn--primary"
          onClick={openNew}
          disabled={busy}
        >
          + New template
        </button>
      </header>

      {/* Messages */}

      {notice && (
        <p
          className="alert alert--success"
          role="status"
        >
          {notice}
        </p>
      )}

      {error && (
        <p
          className="alert alert--error"
          role="alert"
        >
          {error}
        </p>
      )}

      {/* Template form */}

      {editing && (
        <form
          className="admin__card"
          onSubmit={onSubmit}
          noValidate
        >
          <h2>
            {editing === "new"
              ? "New template"
              : "Edit template"}
          </h2>

          {formError && (
            <p
              className="alert alert--error"
              role="alert"
            >
              {formError}
            </p>
          )}

          {/* Template name */}

          <FormField label="Template name">
            {(props) => (
              <input
                {...props}
                type="text"
                required
                maxLength={150}
                value={form.templateName}
                onChange={(event) =>
                  updateField(
                    "templateName",
                    event.target.value
                  )
                }
              />
            )}
          </FormField>

          {/* Description */}

          <FormField label="Description">
            {(props) => (
              <textarea
                {...props}
                rows={3}
                required
                value={form.description}
                onChange={(event) =>
                  updateField(
                    "description",
                    event.target.value
                  )
                }
              />
            )}
          </FormField>

          {/* JSON configuration */}

          <FormField
            label="Default configuration (JSON)"
            hint="Expected returns use percentages (8 = 8%). Risk scores must be whole numbers from 1 to 10. Allocation limits use monetary amounts."
          >
            {(props) => (
              <textarea
                {...props}
                className="admin__code"
                rows={18}
                spellCheck={false}
                required
                value={form.defaultConfigJson}
                onChange={(event) =>
                  updateField(
                    "defaultConfigJson",
                    event.target.value
                  )
                }
              />
            )}
          </FormField>

          {/* Form actions */}

          <div className="admin__actions">
            <button
              type="submit"
              className="btn btn--primary"
              disabled={busy}
            >
              {busy
                ? "Saving..."
                : editing === "new"
                  ? "Save template"
                  : "Update template"}
            </button>

            <button
              type="button"
              className="btn btn--ghost btn--dark"
              onClick={onFormatJson}
              disabled={busy}
            >
              Format JSON
            </button>

            <button
              type="button"
              className="btn btn--ghost btn--dark"
              onClick={onCancel}
              disabled={busy}
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Template list */}

      {templates === null ? (
        <p>Loading…</p>
      ) : templates.length === 0 ? (
        <div className="admin__card">
          <p className="admin__muted">
            No templates yet. Create the first one.
          </p>
        </div>
      ) : (
        <ul className="admin__grid">
          {templates.map((template) => {
            let assetCount = "?";

            try {
              const config =
                typeof template.default_config_json === "string"
                  ? JSON.parse(template.default_config_json)
                  : template.default_config_json;

              if (Array.isArray(config?.assets)) {
                assetCount = config.assets.length;
              }
            } catch {
              assetCount = "?";
            }

            return (
              <li
                key={template.template_id}
                className="admin__card"
              >
                <h3>{template.template_name}</h3>

                <p>{template.description}</p>

                <p className="admin__muted">
                  {assetCount} assets · created{" "}
                  {formatDateTime(template.created_at)}
                </p>

                <div className="admin__actions">
                  <button
                    type="button"
                    className="btn btn--primary btn--sm"
                    onClick={() => openEdit(template)}
                    disabled={busy}
                  >
                    Edit
                  </button>

                  <button
                    type="button"
                    className="btn btn--ghost btn--sm btn--dark"
                    onClick={() => onDelete(template)}
                    disabled={busy}
                  >
                    Delete
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}

    </section>
  );
}
